/*
 * File:   pdurconfig.c
 * Author: sh70244
 *
 * Created on October 21, 2022, 9:57 AM
 */


#include <xc.h>

void main(void) {
    return;
}
