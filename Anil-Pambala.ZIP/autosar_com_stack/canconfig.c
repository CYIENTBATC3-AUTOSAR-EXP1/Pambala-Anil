/*
 * File:   canconfig.c
 * Author: sh70244
 *
 * Created on October 20, 2022, 3:24 PM
 */


#include <xc.h>

void main(void) {
    set_mode();
    return;
}
