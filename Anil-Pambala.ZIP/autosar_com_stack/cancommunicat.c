/*
 * File:   cancommunicat.c
 * Author: sh70244
 *
 * Created on October 20, 2022, 3:25 PM
 */

//communication service which generate signal
#include <xc.h>
//#include "pdur.h"
#include "communicat.h"
#include "communicatconfig.h"

unsigned int signal1=10;
void communication(unsigned int) 
{
   
    pdur(id,signal,protocol);
    
}
