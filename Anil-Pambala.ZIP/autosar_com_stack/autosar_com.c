/*
 * File:   autosar_com.c
 * Author: sh70244
 *
 * Created on October 21, 2022, 12:49 PM
 */


#include <xc.h>


#include "canif.h"
#include "autosar_communicatconfig.h"

void CAN_Send_signal(int CAN_SIG,int Value)
{    

//    AUTOSAR_MSG1_S.sig_1_s = Value;       
//     CAN_FRAME(0,data);

}